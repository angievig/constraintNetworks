:-use_module(library(clpfd)).
productline(L):-
L=[ Brakes, Carbody, DriveWheel, Engine, TyreType], 
Brakes in 1..3, 
Carbody in 1..3, 
DriveWheel in 1..2, 
Engine in 1..3, 
TyreType in 1..2, 
Carbody#=1, 
labeling([ff],L).