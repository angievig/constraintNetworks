package minimalSets;
/**
 * This class creates the graph for running the algorithm for finding a minimal set of constraints
 * To create this graph we use Java Universal Network Graph Framework - Jung
 * @author Angela Villota <angievig@gmail.com>
 * @version 0
 * @since 0
 * Date: Nov 16th 2016
 */
public class MakeGraph {

}
